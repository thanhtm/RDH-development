function [preR,Rdiffs,preG,Gdiffs,preB,Bdiffs,xpos,ypos]=predict(RGB,tag)


R=RGB(:,:,1);
G=RGB(:,:,2);
B=RGB(:,:,3);
[imh,imw]=size(G);
L=imh*imw/2;
preR = zeros(L,1);
preG = zeros(L,1);
preB = zeros(L,1);
Rdiffs = zeros(L,1);
Gdiffs = zeros(L,1);
Bdiffs = zeros(L,1);
xpos = zeros(L,1);
ypos = zeros(L,1);
index=0;

for i=2:imh-1
    if tag+mod(i,2)==2
        k=0;
    else
        k=tag+mod(i,2);
    end
    for j=2+k:2:imw-1
        
        index=index+1;
        
         
         near_R=[R(i-1,j),R(i,j-1),R(i+1,j),R(i,j+1)];
         pre=floor(sum(near_R)/4); 
         preR(index)=pre;
         Rdiffs(index)=R(i,j)-pre; 

%          near_G=[G(i-1,j),G(i,j-1),G(i+1,j),G(i,j+1)];
%          pre=WLSpredictor(near_R,near_G,R(i,j));
%          preG(index)=pre;
%          Gdiffs(index)=G(i,j)-pre;
%          
%          near_B=[B(i-1,j),B(i,j-1),B(i+1,j),B(i,j+1)];
%          pre=WLSpredictor(near_G,near_B,G(i,j));
%          preB(index)=pre;
%          Bdiffs(index)=B(i,j)-pre;
         
%         
         near_B=[B(i-1,j),B(i,j-1),B(i+1,j),B(i,j+1)];
         pre=floor(sum(near_B)/4); 
         preB(index)=pre;
         Bdiffs(index)=B(i,j)-pre; 
         
         near_G=[G(i-1,j),G(i,j-1),G(i+1,j),G(i,j+1)];
         pre=floor(sum(near_G)/4); 
         preG(index)=pre;
         Gdiffs(index)=G(i,j)-pre;
         

            xpos(index)=i;
            ypos(index)=j;
            
        
    end
end
preR=preR(1:index);
preG=preG(1:index);
preB=preB(1:index);
Rdiffs=Rdiffs(1:index);
Gdiffs=Gdiffs(1:index);
Bdiffs=Bdiffs(1:index);
xpos=xpos(1:index);
ypos=ypos(1:index);
%  hist(Rdiffs,min(Rdiffs):max(Rdiffs))
%  figure
%  hist(Gdiffs,min(Gdiffs):max(Gdiffs))
%  figure
%  hist(Bdiffs,min(Bdiffs):max(Bdiffs))
%  length(find(Rdiffs==0))/length(Rdiffs)
%  length(find(Gdiffs==0))/length(Gdiffs)
%  length(find(Bdiffs==0))/length(Bdiffs)
%  
 compresscoder(Rdiffs);
 compresscoder(Gdiffs);
 compresscoder(Bdiffs);
 
end