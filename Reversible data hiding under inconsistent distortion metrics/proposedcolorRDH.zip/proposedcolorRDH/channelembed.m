function [Mod_diffs,embedmessL,flag]=channelembed(C,diffs,messL0,messL,mask)
%%%%% mask1 �ο�ֵ,  channel ��ǰͨ��������messLѡȡ���ֵ������ϢǶ��
flag=true;
[imh,imw]=size(C);
varC = -1*ones(imh,imw);
Mod_diffs=diffs;
tag=mod(mask(1,1)+1,2);
for i=2:imh-1
    if tag+mod(i,2)==2
        k=0;
    else
        k=tag+mod(i,2);
    end
    for j=2+k:2:imw-1  
         varC(i,j)=var( [C(i-1,j),C(i,j-1),C(i+1,j),C(i,j+1)]);
    end
end
varC=varC.*mask;
var_diffs=varC((find(mask==1)));

var_diffs0=sort(var_diffs);
var_max=var_diffs0(round(0.8*length(var_diffs)));
varCT=min  (var_max,var_diffs0( min( 6*(messL+1800),length(var_diffs0) ) ) );
% %  for varT=1:2:2001
% %     if length( find( (var_diffs<=varT)&(var_diffs>-1) ) )<round(5*messL)
% %          varCT=varT;
% %     else
% %          break;
% %     end
% %  end

indexC=find( (var_diffs<=varCT)&(var_diffs>-1) );
diffs1=diffs(indexC);
% figure,hist(diffs1,min(diffs1):max(diffs1));

rate=0.01;T=41;%%%%%%%%%% 31 is proper
histC=hist(diffs1,-T:T);histC(1)=0;histC(end)=0;
TopC=max(histC);poshist=find(histC>(rate*TopC));
TC=abs(poshist(1)-T-1); 
TC=max(TC,20); 
L=-TC;
U=TC;
pos_sel =  find( (diffs1>=L)&(diffs1<=U) );
diffs0=diffs1(pos_sel);

histX=hist(diffs0,L:U);
N=length(diffs0);
Px=histX'/N;
x = L:U;
y = L:U;
% squre error distortion matirx
mB = length(x);
nB = length(y);
Dxy=zeros(mB,nB);
for ii=1:mB
    for jj=1:nB
        Dxy(ii,jj) = (x(ii)-y(jj))*(x(ii)-y(jj));
    end
end

r = (messL+12*length(histX))/N;
Hx = -sum(Px.*log2(Px+eps));
rMax = 0.8*(log2(nB)-Hx);
if r>rMax
    r = rMax;
    disp('embedding rate exceeds maximum.');
end

tag=0;
iteration=0;
rtest=r;
%for i=1:length(rtest)
       while(~tag)
            iteration=iteration+1;
                if(iteration>5)
                    tag=1;
                end
                if(rtest>rMax)
                    rtest = rMax;
                    tag=1;
                elseif(rtest<0)
                    rtest = 0.01;
                    tag=1;
                end
        Hy = (rtest+Hx)*log(2);
        Py = minDistortionEmr(Px,Dxy,Hy);%%%%%%���ŵ�����ͼ�ֲ�����
        Hy=-sum(Py.*log2(Py+eps));
        dH=Hy-Hx;
                if ((dH-r)>-0.0001)&&((dH-r)<=0.005)
                    tag=1;
                 else
                 rtest=rtest*abs(r/dH);
%                 elseif dH<r
%                         rtest=rtest*1.05;
%                     else
%                         rtest=rtest*0.95;
                end
        end 
dHist=round((Py-Px)*N);
histLen=max(1,round(entropy(dHist)*length(dHist)));
% non crossing edges property to get conditional probability Pxy and Pyx
[Qxy,Qyx] = nonCrossEdge(Px,Py);
Qyx=pre_processing(Qyx);
Qxy=pre_processing(Qxy);
% recursive embedding message
%% [~,messLen,extraLen] = recursiveConstruct(Qxy,Qyx,diffs0,x,y,mB,20),messLen-extraLen
[Mod_diffs0,messLen] = recursiveConstruct(Qxy,Qyx,diffs0,x,y,mB,30);
embedmessL = messLen-histLen;
if embedmessL<0.95*messL0
    flag=false;
end
% mod_diffs0 =simulate (Qxy,diffs0,x,y);
% dH=entropy(mod_diffs0)-entropy(diffs0);
% messLen=round(0.98*dH*length(diffs0(:)));
% appraise_PSNR(Mod_diffs0,diffs0),Mod_diffs0=diffs0;
Mod_diffs(indexC(pos_sel))=Mod_diffs0;
lsbC=diffs(find( (var_diffs>varCT) ));
histLen=min(histLen,length(lsbC));
lsbC(1:histLen)=2*floor(lsbC(1:histLen)/2)+round(rand(histLen,1));
Mod_diffs((var_diffs>varCT))=lsbC;
end