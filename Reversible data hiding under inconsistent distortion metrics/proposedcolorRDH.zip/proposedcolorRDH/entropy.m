function H=entropy(signal)
signal=double(signal(:));
nbins=min(signal):max(signal);
hist_signal=hist(signal,nbins);
P_s=hist_signal/(sum(hist_signal));
P=P_s(P_s>0);
H=0;
for i=1:length(P)
    H=H-P(i)*log2(P(i));
end
end