function [partR,partG,partB] = poaloadlocate(Rdiffs,Gdiffs,Bdiffs,messL,perc)

T=40;
L=-T;
U=T;

R_pos_sel =  find( (Rdiffs>=L)&(Rdiffs<=U) );
Rdiffs0=Rdiffs(R_pos_sel);

G_pos_sel = find( (Gdiffs>=L)&(Gdiffs<=U) );
Gdiffs0=Gdiffs(G_pos_sel);

B_pos_sel = find( Bdiffs>=L&Bdiffs<=U );
Bdiffs0=Bdiffs( B_pos_sel );

[~,Px_sub_L,~,~,cover_stitch,D_stitch]=stitch(Rdiffs0,Gdiffs0,Bdiffs0,T);%%%��Ӧ��Ϊcost������

histX=hist(cover_stitch,-T:(T+2*(2*T+1)));
%histLen = compressFun(hist2);  % compress histgram
N = length(Rdiffs0)+length(Gdiffs0)+length(Bdiffs0);
Px = histX'/N;

nB=length(histX);

r = (messL+8*length(histX))/N;
Hx = -sum(Px.*log2(Px+eps));

rMax = (log2(nB)-Hx);
if r>rMax
    r = rMax-0.01;
    disp('embedding rate exceeds maximum.');
end

tag=0;
iteration=0;
rtest=r;
%for i=1:length(rtest)
        while(~tag)
            iteration=iteration+1;
                if(iteration>5)
                    tag=1;
                end
                if(rtest>rMax)
                    rtest = rMax-0.1;
                    tag=1;
                elseif(rtest<0)
                    rtest = 0.01;
                    tag=1;
                end
        Hy = (rtest+Hx)*log(2);
        Py = minDistortionEmr(Px,D_stitch,Hy);%%%%%%���ŵ�����ͼ�ֲ�����
        Hy=-sum(Py.*log2(Py+eps));
        dH=Hy-Hx;
                if ((dH-r)>-0.0001)&&((dH-r)<0.005)
                    tag=1;
                else
                rtest=rtest*abs(r/dH);
%                 elseif dH<r
%                         rtest=rtest*1.05;
%                     else
%                         rtest=rtest*0.95;
                end
        end       
XL=zeros(3,1);
start=0;
for i=1:3
    dis=abs(   sum(Px( start+1:start+Px_sub_L(i) )) -sum( Py (start+1:start+Px_sub_L(i) ))  ) ;
    if ( dis <10^-10 )      
        Px_temp= Px(start+1:start+Px_sub_L(i));
        Py_temp= Py(start+1:start+Px_sub_L(i));
        Px_temp=Px_temp(Px_temp>0);
        Py_temp=Py_temp(Py_temp>0);
        Hx=0;
        Hy=0;
        for j=1:length( Px_temp)
             Hx=Hx- Px_temp(j)*log2( Px_temp(j));
             Hy=Hy- Py_temp(j)*log2( Py_temp(j));
        end
        XL(i)=(Hy-Hx)*sum(Px(start+1:start+Px_sub_L(i)))*N;
        start=start+Px_sub_L(i);
    else
        error('���������');
    end
end
% plot(Px,'r'), hold on, plot(Py,'g')
partR=double(uint8(round(XL(1)/sum(XL)*perc)));
partG=double(uint8(round(XL(2)/sum(XL)*perc)));
partB=double(perc-partR-partG);
end

