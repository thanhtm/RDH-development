% clear
% close all
% clc
% addpath utils\
% img=zeros(510,510);
% mask1=zeros(size(img, 1), size(img, 2));
% mask2=mask1;
% rows1 = 1:2:size(img, 1);
% rows2 = 2:2:size(img, 1);
% cols1 = 1:2:size(img, 2);
% cols2 = 2:2:size(img, 2);
% mask1(rows1, cols1) = 1;
% mask1(rows2, cols2) = 1;
% mask2(rows1, cols2) = 1;
% mask2(rows2, cols1) = 1;
% % % %%%%%%%
% % img = imread('airplane.png');
% % img = double(img);
% % psnr=zeros(10,1);
% % graypsnr=zeros(10,1);
% % messLen=zeros(10,1);
% % i=0;
% % bpp=1.03;
% % for messL=30000:30000:210000
% %      partR=0;partG=0;partB=0;
% %      [stegot,messLen1,partR,partG,partB]=embed(img,round(bpp*messL/2),mask1,partR,partG,partB);
% %      [stego,messLen2,~,~,~]=embed(stegot,round(bpp*messL/2),mask2,partR,partG,partB); 
% %      i=i+1;
% %      messLen(i)=messLen1+messLen2;%pure mewssage
% %      psnr(i)=evaluateColorImage(img,stego) ;
% %      graypsnr(i)=evaluateGrayImage(img,stego);  
% % end
% %  save psnr_airplane_single psnr
% %  save graypsnrn_airplane_single graypsnr
%  
% %%%%%%%%%%%%%%%% barbara
% img = imread('barbara.png');
% img = double(img);
% psnr=zeros(10,1);graypsnr=zeros(10,1);
% messLen=zeros(10,1);
% i=0;
% bpp=1.03;
for messL=90000:10000:110000
     partR=0;partG=0;partB=0;
     [stegot,messLen1,partR,partG,partB]=embed(img,round(bpp*messL/2),mask1,partR,partG,partB);
%      partR=0;partG=0;partB=0;
     [stego,messLen2,partR,partG,partB]=embed(stegot,round(bpp*messL/2),mask2,partR,partG,partB); 
     i=i+1;
     messLen(i)=messLen1+messLen2;%pure mewssage
     psnr(i)=evaluateColorImage(img,stego) ;
     graypsnr(i)=evaluateGrayImage(img,stego);
end
 save psnr_barbara_single psnr
 save graypsnr_barbara_single graypsnr
%  
% tic
% img = imread('airplane.png');
% img = double(img);
% psnr=zeros(10,1);
% messLen=zeros(10,1);graypsnr=zeros(10,1);
% i=0;
% bpp=1.03;
% for messL=30000:20000:210000%:0.1:1
%      partR=0;partG=0;partB=0;
%      [stegot,messLen1,partR,partG,partB]=embed(img,round(bpp*messL/2),mask1,partR,partG,partB);
%      [stego,messLen2,~,~,~]=embed(stegot,round(bpp*messL/2),mask2,partR,partG,partB); 
%      i=i+1;
%      messLen(i)=messLen1+messLen2;%pure mewssage
%      psnr(i)=evaluateColorImage(img,stego);
%      graypsnr(i)=evaluateGrayImage(img,stego);
%      toc
% end
%  save psnr_lena_single psnr
%  save graypsnr_lena_single graypsnr
%  
% img = imread('baboon.png');
% img = double(img);
% total_psnr=[];
% total_bpp=[];
% psnr=zeros(10,1);graypsnr=zeros(10,1);
% messLen=zeros(10,1);
% i=0;
% bpp=1.03;
% for messL=30000:5000:75000%:0.1:1
%      partR=0;partG=0;partB=0;
%      [stegot,messLen1,partR,partG,partB]=embed(img,round(bpp*messL/2),mask1,partR,partG,partB);
%      [stego,messLen2,~,~,~]=embed(stegot,round(bpp*messL/2),mask2,partR,partG,partB); 
%      i=i+1;
%      messLen(i)=messLen1+messLen2%pure mewssage
%      psnr(i)=evaluateColorImage(img,stego);
%      graypsnr(i)=evaluateGrayImage(img,stego);
% end
%  save psnr_baboon_single psnr
%  save graypsnr_baboon_single graypsnr
%  