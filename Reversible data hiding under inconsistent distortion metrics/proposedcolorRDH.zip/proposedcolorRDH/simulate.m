% xRange=1:3;
% yRange=1:3;
% Qxy=[0.3,0.3,0.4;0,0.4,0.6;0.7,0.3,0]
% cover=[1,1,1,1,1,2,2,2,2,2,3,3,3,3,3]

function [stego] =simulate (Qxy,cover,xRange,yRange)

stego = cover;
[m,n] = size(Qxy);
for xi=1:m
    pos = find(cover==xRange(xi));
    xN = length(pos);
    symbols=[];
    start=0;
    
    if xN>0
%         yi = find(abs(Qxy(xi,:)-1.0) < eps);
%         if yi
%             stego(pos) = yRange(yi)*ones(xN,1);
%         else%if abs(sum(Qxy(xi,:))-1.0)<1e-8
            fq = Qxy(xi,:);
            y_num=round(fq*xN);
            maxid=min(sum(y_num),xN);
            pos=pos(1:maxid);
            symbols=zeros(size(pos));
                for i=1:n
                    if(y_num(i)>0)
                       % y_num(i);
                symbols(start+1:start+y_num(i))=i*ones(y_num(i),1);
                start=start+y_num(i);
                    end
                end
            randid=randperm(maxid);
            symbols=symbols(randid);
            stego(pos) = yRange(symbols);      
            %stego(pos)
    end
end



end