function [move_L,Px_sub_L,sub_index,histLen,cover_stitch,D_stitch]=stitch(Rdiffs,Gdiffs,Bdiffs,T)
%%%% �ú���Ŀ�� �����ݷ�Ϊ K�� ����ÿһ�����������������  ��С�������
% cover=[1,2,3,7,8,9,4,5,6,0]; cost=[1, 2.1, 3, 1.1, 2, 2, 1, 1.4, 3, 1]; K=3
% cover=[1,1,2,1,1,2,1,1,2]; cost=[1, 2, 3, 1, 2, 3,1, 2, 3]; K=3
inf=10^20;
K=3;
move_L=zeros(K,1);
Px_sub_L=zeros(K,1);
cover_stitch=[];
sub_index=cell(K,1);
D_stitch=[];

%%%%%����ʵ��
% L=length(cover);
% cost_K=[ones(floor(L/2),1); 2*ones(floor(L/4),1); 3*ones(L-floor(L/4)-floor(L/2),1)];
% center=[1,2,3];
%%%%%%%
% minCover=zeros(K,1);
histLen=0;
start=0;
cost=ones(1,3);
cost(1)=0.299;
cost(2)=0.587;
cost(3)=0.114;
%center
U=T;
L=-T;
    for i=1:K
        if i==1
            temp=Rdiffs;
        elseif i==2
            temp=Gdiffs;
        else
            temp=Bdiffs;
        end
        

        sub_index{i}=start+1:start+length(temp);
        start=start+length(temp);     
%         histX=hist(temp,L:U);
%         histLen = compressFun(histX)+histLen;
        Px_sub_L(i)=U-L+1;
                        x = L:U;
                        y = L:U;
                        % squre error distortion matirx
                        mB = length(x);
                        nB = length(y);
                        Dxy=zeros(mB,nB);
                        for ii=1:mB
                            for jj=1:nB
                                Dxy(ii,jj) = (x(ii)-y(jj))^2;
                            end
                        end
                      Dxy=cost(i)*Dxy;
                      D_stitch=[D_stitch inf*ones(size(D_stitch,1),size(Dxy,2));inf*ones(size(Dxy,2),size(D_stitch,1)) Dxy];                   
                if i>1
                    move_L(i)=max(cover_stitch)-min(temp)+1; 
                end
                cover_stitch=[cover_stitch; temp+move_L(i)];    
    end
end




