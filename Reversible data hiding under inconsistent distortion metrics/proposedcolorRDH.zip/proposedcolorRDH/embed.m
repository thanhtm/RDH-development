function [waterMark,messLen,partR,partG,partB]=embed(img,messL,mask1,partR,partG,partB)
RGB=double(img);
R=RGB(:,:,1);
G=RGB(:,:,2);
B=RGB(:,:,3);
perc=50;%%��Ϊ20��
T=40;
waterMark=RGB;
mask2=1-mask1;%%%mask2��Ԥ��ֵ��Ƕ���  mask1�ο�ֵ
Rref=R.*mask1;
PR0=R.*mask2;
[Rmean_a1,Rmean_a2,Rmean_b]=guidedfilter(G,B, Rref, mask1);
tentativeP = Rmean_a1 .* G +Rmean_a2 .* B+ Rmean_b;
tentativeP(find(tentativeP>255))=255;
tentativeP(find(tentativeP<0))=0;
PreR =round(tentativeP);
PE0 = (PR0-PreR).*mask2;
Rdiffs0=PE0(find(mask2==1));

Gref=G.*mask1;
PG0=G.*mask2;
[Gmean_a1,Gmean_a2,Gmean_b]=guidedfilter(R,B, Gref, mask1);
tentativeP = Gmean_a1 .* R +Gmean_a2 .* B+ Gmean_b;
tentativeP(find(tentativeP>255))=255;
tentativeP(find(tentativeP<0))=0;
PreG =round(tentativeP);
PE0 = (PG0-PreG).*mask2;
Gdiffs0=PE0(find(mask2==1));

Bref=B.*mask1;
PB0=B.*mask2;
[Bmean_a1,Bmean_a2,Bmean_b]=guidedfilter(R,G, Bref, mask1);
tentativeP = Bmean_a1 .* R +Bmean_a2 .* G+ Bmean_b;
tentativeP(find(tentativeP>255))=255;
tentativeP(find(tentativeP<0))=0;
PreB =round(tentativeP);
PE0 = (PB0-PreB).*mask2;
Bdiffs0=PE0(find(mask2==1));
if (partR+partG+partB)~=perc
[partR,partG,partB] = poaloadlocate(Rdiffs0,Gdiffs0,Bdiffs0,messL,perc);%%%%%%%% ��������payload
end
% figure, hist(Rdiffs0,min(Rdiffs0):max(Rdiffs0))
% figure, hist(Gdiffs0,min(Gdiffs0):max(Gdiffs0))
% figure, hist(Bdiffs0,min(Bdiffs0):max(Bdiffs0))

% appraise_PSNR(Mod_Gdiffs,Gdiffs),appraise_PSNR(G,RGB(:,:,2))
%  figure,hist(Gdiffs0,min(Gdiffs0):max(Gdiffs0));
%  figure,hist(Gdiffs,min(Gdiffs):max(Gdiffs));
if partR
tentativeP = Rmean_a1 .* G +Rmean_a2 .* B+ Rmean_b;
tentativeP(find(tentativeP>255))=255;
tentativeP(find(tentativeP<0))=0;
PreR =round(tentativeP);
PE0 = (PR0-PreR).*mask2;
Rdiffs=PE0(find(mask2==1));

flag=true;
messL0=round(partR*messL/perc);
messL1=messL0;
[Mod_Rdiffs,RmessLen,flag]=channelembed(R,Rdiffs,messL0,messL1,mask2);
    itr=0;
    while ~flag
    itr=itr+1;
        if itr>3
            flag=true;
        else
            messL1=messL0+messL1-RmessLen;
            [Mod_Rdiffs,RmessLen,flag]=channelembed(R,Rdiffs,messL0,messL1,mask2);
        end
    end

PE0(find(mask2==1))=Mod_Rdiffs;%%%%%%%appraise_PSNR( PE0(find(mask2==1)), Mod_Rdiffs)
rstoR=PE0+PreR;

flow=[];
flow0_id=find(rstoR<=0);
flow0=-rstoR(flow0_id);
flow255_id=find(rstoR>=255);
flow255=rstoR(flow255_id)-255;
flow=[flow0;flow255];
%max(flow)
if length(unique(flow))<=1
    R_flow=1;
else
    R_flow=compresscoder(flow);
end
lsbR=Mod_Rdiffs(find( (Mod_Rdiffs>T) ));
R_flow=min(R_flow,length(lsbR));
lsbR(1:R_flow)=2*floor(lsbR(1:R_flow)/2)+round(rand(R_flow,1));
Mod_Rdiffs(find( (Mod_Rdiffs>T) ))=lsbR;
PE0(find(mask2==1))=Mod_Rdiffs;
rstoR=PE0+PreR;
RmessLen=RmessLen-R_flow;
R(find(mask2==1))=rstoR(find(mask2==1));
else
   RmessLen=0; 
end
% appraise_PSNR(Mod_Rdiffs,Rdiffs),appraise_PSNR(R,RGB(:,:,1))
% figure,hist(Rdiffs,min(Rdiffs):max(Rdiffs));
% plot(histX)


if partG
tentativeP = Gmean_a1 .* R +Gmean_a2 .* B+ Gmean_b;
tentativeP(find(tentativeP>255))=255;
tentativeP(find(tentativeP<0))=0;
PreG =round(tentativeP);
PE0 = (PG0-PreG).*mask2;
Gdiffs=PE0(find(mask2==1));
flag=true;
messL0=round(partG*messL/perc);
messL1=messL0;
[Mod_Gdiffs,GmessLen,flag]=channelembed(G,Gdiffs,messL0,messL1,mask2);
    itr=0;
    while ~flag
    itr=itr+1;
        if itr>3
            flag=true;
        else
            messL1=messL0+messL-GmessLen;
            [Mod_Gdiffs,GmessLen,flag]=channelembed(G,Gdiffs,messL0,messL1,mask2);
        end
    end
PE0(find(mask2==1))=Mod_Gdiffs;
rstoG=PE0+PreG;

flow=[];
flow0_id=find(rstoG<=0);
flow0=-rstoG(flow0_id);
flow255_id=find(rstoG>=255);
flow255=rstoG(flow255_id)-255;
flow=[flow0;flow255];
%max(flow)
if length(unique(flow))<=1
    G_flow=1;
else
    G_flow=compresscoder(flow);
end
lsbG=Mod_Gdiffs(find( (Mod_Gdiffs>T) ));
G_flow=min(G_flow,length(lsbG));
lsbG(1:G_flow)=2*floor(lsbG(1:G_flow)/2)+round(rand(G_flow,1));
Mod_Gdiffs(find( (Mod_Gdiffs>T) ))=lsbG;%%%appraise_PSNR(Mod_Gdiffs(find( (Mod_Gdiffs>T) )),lsbG)
PE0(find(mask2==1))=Mod_Gdiffs;
rstoG=PE0+PreG;
GmessLen=GmessLen-G_flow;

G(find(mask2==1))=rstoG(find(mask2==1));
else
   GmessLen=0; 
end


if partB
tentativeP = Bmean_a1 .* R +Bmean_a2 .* G+ Bmean_b;
tentativeP(find(tentativeP>255))=255;
tentativeP(find(tentativeP<0))=0;
PreB =round(tentativeP);
PE0 = (PB0-PreB).*mask2;
Bdiffs=PE0(find(mask2==1));
% % Bdiffs=Bdiffs0;
flag=true;
messL0=round(partB*messL/perc);
messL1=messL0;
[Mod_Bdiffs,BmessLen,flag]=channelembed(B,Bdiffs,messL0,messL1,mask2);
 itr=0;
    while ~flag
    itr=itr+1;
        if itr>3
            flag=true;
        else
            messL1=messL0+messL-BmessLen;
            [Mod_Bdiffs,BmessLen,flag]=channelembed(B,Bdiffs,messL0,messL1,mask2);
        end
    end
PE0(find(mask2==1))=Mod_Bdiffs;
rstoB=PE0+PreB;


flow=[];
flow0_id=find(rstoB<=0);
flow0=-rstoB(flow0_id);
flow255_id=find(rstoB>=255);
flow255=rstoB(flow255_id)-255;
flow=[flow0;flow255];
%max(flow)
if length(unique(flow))<=1
    B_flow=1;
else
    B_flow=compresscoder(flow);
end
lsbB=Mod_Bdiffs(find( (Mod_Bdiffs>T) ));
B_flow=min(B_flow,length(lsbB));
lsbB(1:B_flow)=2*floor(lsbB(1:B_flow)/2)+round(rand(B_flow,1));
Mod_Bdiffs(find( (Mod_Bdiffs>T) ))=lsbB;
PE0(find(mask2==1))=Mod_Bdiffs;
rstoB=PE0+PreB;
BmessLen=BmessLen-B_flow;

B(find(mask2==1))=rstoB(find(mask2==1));
else
   BmessLen=0; 
end



% figure,hist(Bdiffs0,min(Bdiffs0):max(Bdiffs0));
% figure,hist(Bdiffs,min(Bdiffs):max(Bdiffs));
% appraise_PSNR(Mod_Bdiffs,Bdiffs),appraise_PSNR(B,RGB(:,:,3)) figure, hist(Bdiffs,min(Bdiffs):max(Bdiffs));
waterMark(:,:,1)=R;
waterMark(:,:,2)=G;
waterMark(:,:,3)=B;

messLen=RmessLen+GmessLen+BmessLen;
waterMark=uint8(waterMark);
end


