
function imDst = boxfilter(imSrc, h, v)

[hei, wid] = size(imSrc);
imDst = zeros( size(imSrc) );

if v ~= 0
%cumulative sum over Y axis
imCum = cumsum(imSrc, 1);
%difference over Y axis
imDst(1:v+1, :) = imCum(1+v:2*v+1, :);
imDst(v+2:hei-v, :) = imCum(2*v+2:hei, :) - imCum(1:hei-2*v-1, :);
imDst(hei-v+1:hei, :) = repmat(imCum(hei, :), [v, 1]) - imCum(hei-2*v:hei-v-1, :);
end

if h ~= 0
    if v ~= 0
        %cumulative sum over X axis
        imCum = cumsum(imDst, 2);
    else
        %cumulative sum over X axis
        imCum = cumsum(imSrc, 2);
    end
%difference over Y axis
imDst(:, 1:h+1) = imCum(:, 1+h:2*h+1);
imDst(:, h+2:wid-h) = imCum(:, 2*h+2:wid) - imCum(:, 1:wid-2*h-1);
imDst(:, wid-h+1:wid) = repmat(imCum(:, wid), [1, h]) - imCum(:, wid-2*h:wid-h-1);
end

end