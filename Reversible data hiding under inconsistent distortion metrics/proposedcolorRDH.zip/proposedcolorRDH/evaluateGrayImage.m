function psnr=evaluateGrayImage(img1,img2 )
%APPRAISE Summary of this function goes here
%   Detailed explanation goes here
img1=rgb2gray(uint8(img1));
img2=rgb2gray(uint8(img2));
img1=double(img1);
img2=double(img2);
L=length(img1(:));
mse = sum((img1(:)-img2(:)).^2)/L;

psnr=10*log10(255*255/mse);


