function [mean_a1,mean_a2,mean_b] = guidedfilter(R1, R2, P, mask)

h=3;  %window size (3*2+1)*(3*2+1)
v=3;

F=[-1,0,-1;
    0,4,0;
    -1,0,-1];
Lap_R1 = imfilter(R1.*mask, F, 'replicate');
Lap_R2 = imfilter(R2.*mask, F, 'replicate');
Lap_P = imfilter(P, F, 'replicate');

% Image size
[hei, wid] = size(R1); 
% The number of the sammpled pixels in each local patch
N = boxfilter(mask, h, v);
N(find(N == 0)) = 1;
% The size of each local patch; N=(2r+1)^2 except for boundary pixels.
N2 = boxfilter(ones(hei, wid), h, v);

sum_Lap_R1P=boxfilter(Lap_R1.*Lap_P.*mask, h, v);
sum_Lap_R2P=boxfilter(Lap_R2.*Lap_P.*mask, h, v);

sum_Lap_R1R2=boxfilter(Lap_R1.*Lap_R2.*mask, h, v);
sum_Lap_R1R1=boxfilter(Lap_R1.*Lap_R1.*mask, h, v);
sum_Lap_R2R2=boxfilter(Lap_R2.*Lap_R2.*mask, h, v);

a = zeros(hei, wid, 2);
for y=1:hei
    for x=1:wid        
        sum1=[sum_Lap_R1R1(y, x),sum_Lap_R1R2(y, x);
            sum_Lap_R1R2(y, x),sum_Lap_R2R2(y, x)];
        sum2= [sum_Lap_R1P(y, x);sum_Lap_R2P(y, x)];
             
        
        a(y, x, :) = pinv(sum1+ eps * eye(2))*sum2;
%         a(y, x, :) = double(inv(sym(sum1+ eps * eye(2))))*sum2;% Eqn. (14) in the paper;
    end
end

mean_R1 = boxfilter(R1.*mask, h, v) ./ N;
mean_R2 = boxfilter(R2.*mask, h, v) ./ N;
mean_P = boxfilter(P.*mask, h, v) ./ N;
b = mean_P - a(:, :, 1) .* mean_R1- a(:, :, 2) .* mean_R2 ; 

% weighted average a1, a2 and b 
a1=a(:,:,1);
a2=a(:,:,2);
dif= boxfilter(P.*P.*mask,h,v)+boxfilter(R1.*R1.*mask,h,v).*a1.*a1+boxfilter(R2.*R2.*mask,h,v).*a2.*a2+b.*b.*N...
    -2*a1.*boxfilter(P.*R1.*mask,h,v)-2*a2.*boxfilter(P.*R2.*mask,h,v)-2*b.*boxfilter(P.*mask,h,v)...
    +2*a1.*a2.*boxfilter(R1.*R2.*mask,h,v)+2*a1.*b.*boxfilter(R1.*mask,h,v)+2*a2.*b.*boxfilter(R2.*mask,h,v);

% FN=[0 1/2 0;
%     1/2 1 1/2;
%     0 1/2 0];
% complexity_mask=floor(dif.*(-mask+1).*2500./N);
% complexity_mask=floor(imfilter(dif,FN,'replica').*(-mask+1));

dif = dif ./ 2500;
% creat a complexity mask to express the local complexity of P


dif(find(dif<0.01)) = 0.01;
dif = 1./dif;
wdif = boxfilter(dif,h,v);
wdif(find(wdif<0.01)) = 0.01;
mean_a1= boxfilter(a(:, :, 1).*dif,h,v) ./ wdif;
mean_a2= boxfilter(a(:, :, 2).*dif,h,v) ./ wdif;
mean_b = boxfilter(b.*dif,h,v) ./ wdif;

% tentativeP = mean_a1 .* R1 +mean_a2 .* R2+ mean_b;
% tentativeP(find(tentativeP>255))=255;
% tentativeP(find(tentativeP<0))=0;
% Pre =round(tentativeP);

end