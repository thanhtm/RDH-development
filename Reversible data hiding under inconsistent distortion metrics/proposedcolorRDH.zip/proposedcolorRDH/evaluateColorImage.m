function psnr=evaluateColorImage(img1,img2 )
%APPRAISE Summary of this function goes here
%   Detailed explanation goes here
img1=double(img1);
img2=double(img2);
R1=img1(:,:,1);
G1=img1(:,:,2);
B1=img1(:,:,3);

R2=img2(:,:,1);
G2=img2(:,:,2);
B2=img2(:,:,3);


L=length(img1(:))/3;
mse=0.299*sum((R1(:)-R2(:)).^2)+0.587*sum((G1(:)-G2(:)).^2)+0.114*sum((B1(:)-B2(:)).^2);
% mse=sum((R1(:)-R2(:)).^2)+sum((G1(:)-G2(:)).^2)+sum((B1(:)-B2(:)).^2);
mse = mse/L;
psnr=10*log10(255*255/mse);