function result=smo(x)
v=zeros(1,4);
v(1)=abs(x(1)-x(2));
v(2)=abs(x(2)-x(3));
v(3)=abs(x(3)-x(4));
v(4)=abs(x(4)-x(1));
result=var(v,1);
end