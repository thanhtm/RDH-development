function cost=get_cost(pix)
    v1=abs(pix(1)-pix(2));
    v2=abs(pix(2)-pix(3));
    v3=abs(pix(3)-pix(4));
    v4=abs(pix(1)-pix(4));
    va=var([v1,v2,v3,v4],1);
   
    if va==0
        cost=10^10;
    else
        cost=1/va;
    end
end