clear
close all
clc

imgname = 'baboon.pgm';
img=imread(imgname);
messLen=14000;
K=3;
tic
[stego,rea_messLen]=imagembedding(imgname,1.03*messLen,K);
toc
psnr=appraise_PSNR(img,stego)

% img = double(img);
% for bpp=0.11:0.1:1;
%      [stego1,messLen1]=embed(img,bpp,K,0);
%      [stego,messLen2]=embed(stego1,bpp,K,1);
%      rea_bpp=(messLen1+messLen2)/length(img(:))
%      
%      psnr=appraise_PSNR(img,stego)
% end
