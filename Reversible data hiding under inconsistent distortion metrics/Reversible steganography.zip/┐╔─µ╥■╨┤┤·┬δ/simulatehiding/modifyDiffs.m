function [mod_diffs,messLen,histLen,flag] = modifyDiffs(cover,Dxy,move_L,Px_sub_L,messL,K,T,overtag)
%MODIFYDIFFS Summary of this function goes here
%   Detailed explanation goes here%%%%%%%%%5�޸�
%addpath utils\;
flag=true;
eps=0.0001;
L=-T;
U=T+(K-1)*(2*T+1);
x=L:U;
y = x;
histX=hist(cover,x);

% figure, plot(histX)
N = length(cover);
Px = histX'/N;
nB=length(histX);
r = (messL+8*length(histX))/N;
Hx = -sum(Px.*log2(Px+eps));
rMax = (log2(nB)-Hx)-0.1;

if ~overtag%%%%%%%Ϊ���� ǿ��ִ�д���
    if r>rMax
        disp('embedding rate exceeds maximum.');

        mod_diffs=0;
        messLen=0;
        histLen=0;
        flag=false;
        return
    end
end
% optimize to estimate Py
% optimize to estimate Py
  % convert to logarithm based

tag=0;
iteration=0;
rtest=r;
        while(~tag)
            iteration=iteration+1;
                if(iteration>5)
                    tag=1;
                end
                if(rtest>rMax)
                    rtest = rMax;
                elseif(rtest<0.1)
                    rtest = 0.1;
                end
        Hy = (rtest+Hx)*log(2);
        Py = minDistortionEmr(Px,Dxy,Hy);%%%%%%���ŵ�����ͼ�ֲ�����
        Hy=-sum(Py.*log2(Py+eps));
        dH=Hy-Hx;
                if ((dH-r)>=-0.001)&&((dH-r)<=0.01)
                    tag=1;
                else
                    rtest=rtest*abs(r/dH);
%                 elseif
%                     dH<r
%                         rtest=1.03*rtest;
%                     else
%                         rtest=0.97*rtest;
                end
        end 
% figure, stem(Px), hold on, stem(Py,'r')

K=length(move_L);
Qxy=double(zeros(length(Px),length(Py)));
Qyx=double(zeros(length(Py),length(Px)));
start=0;

for i=1:K
%     dis=abs(   sum(Px( start+1:start+Px_sub_L(i) )) -sum( Py (start+1:start+Px_sub_L(i) ))  ) ;
%     if ( dis <10^-10 ) 
[Qxy_sub,Qyx_sub] = nonCrossEdge(Px(start+1:start+Px_sub_L(i)),Py(start+1:start+Px_sub_L(i)));
Qxy(start+1:start+Px_sub_L(i),start+1:start+Px_sub_L(i))=Qxy_sub;
Qyx(start+1:start+Px_sub_L(i),start+1:start+Px_sub_L(i))=Qyx_sub;
start=start+Px_sub_L(i);
%     else
%         error('���������');
%     end
end
Qyx=pre_processing(Qyx);
Qxy=pre_processing(Qxy);
 [mod_diffs,messLen] = recursiveConstruct(Qxy,Qyx,cover,x,y,K);%%
% �ݹ�������ģ��Ƕ�룬Ч���൱
% messLen,
% mod_diffs =simulate (Qxy,cover,x,y);
% messLen=round(0.98*(entropy(mod_diffs)-entropy(cover))*length(cover(:)));%%%%%%%%

dHist=round((Py-Px)*N);
histLen=round(entropy(dHist)*length(dHist));
messLen = round(messLen-histLen);%%%pure message


% entropy(mod_diffs)-entropy(cover)
%  appraise_PSNR(cover,mod_diffs)
% sum(abs(cover-mod_diffs))
end

