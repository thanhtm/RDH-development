function jnd=get_jnd(near_pix)

T=30;
grad=(near_pix(1)-near_pix(3))^2+(near_pix(2)-near_pix(4))^2;
grad=sqrt(grad);
ave=mean(near_pix(:));
Ta=max(near_pix(:))-min(near_pix(:));

if grad<=T
    a=10;b=20;c=24;
else 
    a=8;b=18;c=22;
end

    if ave<=75
    TL=ave*(a-b)/75+b;
    elseif ave<=125
        TL=a;
      
    else
       TL=(ave-125)*(c-a)/130+a;
    end
    jnd=TL+0.5*Ta/TL;
% % %     near_pix
