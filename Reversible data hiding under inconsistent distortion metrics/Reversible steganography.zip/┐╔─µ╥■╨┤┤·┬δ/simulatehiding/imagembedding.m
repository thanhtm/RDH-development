function [stego,rea_messLen]=imagembedding(imgname,messLen,K)
img = double(imread(imgname));
messLen1=messLen;
hostrate=6;
rate=0.4;
[stego,rea_messLen,flag]=embed(img,messLen,messLen1,K,1,hostrate,rate,false);
itr=0;
    while ~flag
        if (hostrate*messLen<0.2*length(img(:)))
            hostrate=hostrate+2;
        else
            rate=rate+0.05;
        end
    
    messLen1=messLen1+messLen-rea_messLen;
    [stego,rea_messLen,flag]=embed(img,messLen,messLen1,K,1,hostrate,rate,false);
    itr=itr+1;
    if itr>3&&~flag
        itr
        if (hostrate*messLen<0.2*length(img(:)))
            hostrate=hostrate+2;
        else
            rate=rate+0.05;
        end
        [stego,rea_messLen,flag]=embed(img,messLen,messLen1,K,1,hostrate,rate,true); 
        flag=true;
    end
    end

end