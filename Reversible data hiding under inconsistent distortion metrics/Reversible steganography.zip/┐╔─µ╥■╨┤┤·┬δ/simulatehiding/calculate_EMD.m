function EMD=calculate_EMD(Px,Py)

% Px=Px/sum(Px);
% Py=Py/sum(Py);
[Qxy,Qyx] = nonCrossEdge(Px,Py);

EMD=0;
[m,n]=size(Qxy);

for i=1:m
    for j=1:n
        EMD=Px(i)*Qxy(i,j)*((i-j)^2)+EMD;
    end
end

end