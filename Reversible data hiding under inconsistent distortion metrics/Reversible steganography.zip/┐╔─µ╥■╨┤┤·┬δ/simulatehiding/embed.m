function [markimage,puremessL,flag]=embed(img,messL0,messL,K,tag,hostrate,rt,overtag)
flag=true;%%%%%���Ƕ��
img=double(img);
waterMark=img;
[cost,preV,diffs,xpos,ypos]=prediction(img,tag);%%%% ����Ե���������ص�
cost0=sort(cost);
max_cost=cost0((round(rt*length(cost))));
costT=min(  max_cost, cost0(  min  (hostrate*(messL+1800), length(cost0)) )  );
index=find(cost<=costT);

diffs1=diffs(index);
cost1=cost(index);

rate=0.01;
T=46;%%%%%%%%%% 31 is proper
histC=hist(diffs1,-T:T);histC(1)=0;histC(end)=0;
TopC=max(histC);poshist=find(histC>(rate*TopC));
TC=max(abs(poshist(1)-T-1),20); 
L=-TC;
U=TC;

pos_sel =  find( (diffs1>=L)&(diffs1<=U) );
diffs0=diffs1(pos_sel);
cost0=cost1(pos_sel);
%%% figure, hist(diffs,min(diffs):max(diffs))
[move_L,Px_sub_L,sub_index,cover_stitch,D_stitch]=K_means(diffs0,cost0',K,TC);%%%��Ӧ��Ϊcost������
[mod_diffs,embedmessL,histLen,flag2] =  modifyDiffs(cover_stitch,D_stitch,move_L,Px_sub_L,messL,K,TC,overtag); 
if ~overtag
    if ~flag2&&~overtag
        markimage=img;
        puremessL=messL;
        flag=false;
        return
    end
end
%%%%%%%%% ����
%  appraise_PSNR(mod_diffs,cover_stitch)
%    mod_diffs=cover_stitch;
%%%%%%%% ����

index_end=length(mod_diffs);
 for i=K:-1:1
    diffs0(sub_index{i})=mod_diffs(index_end-length(sub_index{i})+1:index_end)-move_L(i);
    index_end=index_end-length(sub_index{i});
 end
 diffs(index(pos_sel))=diffs0;


Ind = sub2ind(size(waterMark),xpos(pos_sel),ypos(pos_sel));
waterMark(Ind) = preV(pos_sel)+diffs(pos_sel);


%% overflow and underflow handling
overP=waterMark(Ind);
flow=[];
flow0_id=find(overP<=0);
flow0=-overP(flow0_id);
flow255_id=find(overP>=255);
flow255=overP(flow255_id)-255;
flow=[flow0;flow255];
% max(flow)
if length(unique(flow))<=1
    L_flow=1;
else
    L_flow=round(compresscoder(flow));
end

pos_lsb=find(abs(diffs)>TC);
L_lsb=min(histLen+ L_flow,length(pos_lsb));
diffs(pos_lsb(1:L_lsb))=2*floor(diffs(pos_lsb(1:L_lsb))/2)+round(rand(L_lsb,1));

waterMark(Ind) = preV(pos_sel)+diffs(pos_sel);

%%%%**** ����
% as=waterMark - img;
% sum(abs(as(:)))
%%%****����

puremessL = embedmessL-L_flow;%%%%%pure message
if puremessL<0.95*messL0
    flag=false;
end
markimage=uint8(waterMark);

end

