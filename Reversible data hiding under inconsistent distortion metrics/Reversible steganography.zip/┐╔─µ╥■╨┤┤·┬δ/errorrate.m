clear;
close all
clc

messLen=[	2000	4000	6000	8000	10000	12000 14000];
messLen=[0,messLen];
% err1=[0.4495   0.4117	0.3622	0.3050	0.2406	0.1933	0.1589];%%%%%%pro
% err2=[ 0.4418  0.3980	0.3122 	0.2532 	0.2071	0.1700	0.1410];%%%%%��׿
% err3=[0.4175	0.3562	0.2764	0.1938	0.1369	0.0921	0.0584];%%%%%%%info science
% err4=[ 0.3353  0.2437	0.1546 	0.1155 	0.0920	0.0768	0.0658];%%% RHM
err1=[ 0.4868    0.4627    0.4230    0.3947    0.3806    0.3633    0.3455];%%%%%%pro
err2=[   0.3980	0.3122 	0.2532 	0.2079	0.1708	0.1450 0.1214];%%%%%��׿
err3=[  	0.3562	0.2764	0.1938	0.1369	0.0921	0.0584 0.040];%%%%%%%info science
err4=[  0.2437	0.1546 	0.1155 	0.0920	0.0768	0.0658 0.0601];%%% RHM
err1=[0.5 err1];
err2=[0.5 err2];
err3=[0.5 err3];
err4=[0.5 err4];


plot(messLen,err1,'m-s','LineWidth',1.5);
hold on
plot(messLen,err2,'c-d','LineWidth',1.5);
hold on
plot(messLen,err3,'g-v','LineWidth',1.5);
hold on
plot(messLen,err4,'r-*','LineWidth',1.5);


set(gca,'YTick',0:0.05:0.5) 
ylabel('Error rate','FontSize',16);
xlabel('Payload(bits)','FontSize',16);
 set(gca,'FontSize',14);
  axis([0 14000 0 0.6]);
 h=legend('Proposed method', 'Zhang et al.''s method [32]','Hong et al.''s method [31]','RHM [20]');
set(h,'Fontsize',12);
set(gca,'box','on')
grid on

