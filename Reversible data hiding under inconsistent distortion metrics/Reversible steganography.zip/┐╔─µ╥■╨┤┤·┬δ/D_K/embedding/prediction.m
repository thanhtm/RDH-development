function [cost,preV,difs,xpos,ypos]=prediction(I,tag)

[imh,imw]=size(I);

L=imh*imw-((imh-2)*2+(imw-2)*2+4);
L=L/2;
% sd=zeros(L,1);
preV = zeros(L,1);
difs = zeros(L,1);
% cost = zeros(L,1);
xpos = zeros(L,1);
ypos = zeros(L,1);


index=0;

for i=2:imh-1
    if tag+mod(i,2)==2
        k=0;
    else
        k=tag+mod(i,2);
    end
    for j=2+k:2:imw-1
         near_pix=[I(i-1,j),I(i,j-1),I(i+1,j),I(i,j+1)];
         pre=floor(sum(near_pix)/4);    
%         dis(index)=std(near_pix,1);�����׼��
            index=index+1; 
            difs(index)=I(i,j)-pre;
            I(i,j)=pre;
%             cost(index)=get_cost(near_pix);
            xpos(index)=i;
            ypos(index)=j;
            preV(index)=pre;
           
    end
end
% cost=cost(1:index);
xpos=xpos(1:index);
ypos=ypos(1:index);
preV=preV(1:index);
difs=difs(1:index);
img_cost=HILLcost(I);
Ind = sub2ind(size(img_cost),xpos,ypos);
cost=img_cost(Ind);

% index=1;
% cost1=zeros(L,1);
% for i=2:imh-1
%     if tag+mod(i,2)==2
%         k=0;
%     else
%         k=tag+mod(i,2);
%     end
%     for j=2+k:2:imw-1
%             cost1(index)=img_cost(i,j);
%             index=index+1; 
%     end
% end
% 
% sum(abs(cost1-cost))

end

