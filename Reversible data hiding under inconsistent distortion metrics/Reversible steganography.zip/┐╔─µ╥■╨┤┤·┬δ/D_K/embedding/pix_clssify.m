function [index_vector]=pix_clssify(difs,jnd,index,class_num)

%%% ����jnd��С������ֵ�ֳ�class_num��  class_num>=2
div_value=zeros(class_num+1,1);
index_vector=cell(class_num,1);
jnd_vector=cell(class_num,1);
difs_vector=cell(class_num,1);
D=cell(class_num,1);

L=length(jnd);
sort_jnd=sort(jnd);
%%%%% ����class_num+1����λ�㡣��β��һ��
for i=2:class_num
    div_value(i)=sort_jnd(round(L/i));
end
div_value(class_num+1)=sort_jnd(end);

for i=1:class_num-1
    index_vector{i}=index( find(jnd>=div_value(i)) && find(jnd<div_value(i+1)) );
    jnd_vector{i}=jnd(index_vector{i});
    difs_vector{i}=difs(index_vector{i});
end
 index_vector{class_num}=index( find(jnd>=div_value(class_num)) && find(jnd<=div_value(class_num+1)) );
 jnd_vector{class_num}=jnd(index_vector{class_num});
 
for i=1:class_num
    [D{i},index_vector{i}]=get_distortion_matrix( difs_vector{i},jnd_vector{i},index_vector(i),threshT);%%%%%ѡȡ�������ص�λ��
    difs_vector{i}=difs(index_vector{i});
end






[D1,index1]=get_distortion_matrix(difs1,jnd1,index1,threshT);%%%%%ѡȡ�������ص�λ��
[D2,index2]=get_distortion_matrix(difs2,jnd2,index2,threshT);

difs1=difs(index1);
difs2=difs(index2);
shift_dis=(max(difs1)-min(difs2))+1;%%%ƽ�ƾ�����Ҫ��¼
difs2=difs2+shift_dis;
combine_diffs=[difs1;difs2];%%%%% ֱ��ͼ�ϲ�
combine_D=ones(size(D1,1)+size(D2,1),size(D1,2)+size(D2,2))*inf;
combine_D(1:size(D1,1),1:size(D1,2))=D1;
combine_D(1+size(D1,1):end,1+size(D1,2):end)=D2;%%%% ʧ�����ϲ�

max_difs1=max(difs1);%%%%ֱ��ͼƽ�Ʒֽ����Ҫ��¼
mess_L=length(combine_diffs);

overLen = 4000;

 [mod_diffs,messLen,histLen] = modifyDiffs(combine_diffs(1:mess_L-overLen),combine_D,bpp);

 mod_diffs=[mod_diffs;combine_diffs(1+mess_L-overLen:end)];%%%%�������lsbλǶ��Ϣ
