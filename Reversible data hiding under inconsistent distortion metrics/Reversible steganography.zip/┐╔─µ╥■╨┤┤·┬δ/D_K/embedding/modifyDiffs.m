function [mod_diffs,messLen,flag] = modifyDiffs(cover,Dxy,move_L,Px_sub_L,messL,K,T)
%MODIFYDIFFS Summary of this function goes here
%   Detailed explanation goes here%%%%%%%%%5�޸�
%addpath utils\;
flag=1;
eps=0.0001;
L=-T;
U=T+(K-1)*(2*T+1);
x=L:U;
y = x;
hist2=hist(cover,x);
N = length(cover);
Px = hist2'/N;
nB=length(hist2);
r = messL/N;
Hx = -sum(Px.*log2(Px+eps));
rMax = (log2(nB)-Hx);
if r>rMax
    r =0.99*rMax;
    flag=1;
    disp('embedding rate exceeds maximum.');
end

% optimize to estimate Py
% optimize to estimate Py
  % convert to logarithm based
tag=0;
iteration=0;
rtest=r;
        while(~tag)
            iteration=iteration+1;
                if(iteration>10)
                    tag=1;
                end
                if(rtest>rMax)
                    rtest = 0.99*rMax;
                    tag=1;
                elseif(rtest<0.01)
                    rtest = 0.1;
                    tag=1;
                end
        Hy = (rtest+Hx)*log(2);
        Py = minDistortionEmr(Px,Dxy,Hy);%%%%%%���ŵ�����ͼ�ֲ�����
        Hy=-sum(Py.*log2(Py+eps));
        dH=Hy-Hx;
                if ((dH-r)>0)&&((dH-r)<=0.005)
                    tag=1;
                elseif dH<r
                        rtest=1.05*rtest;
                    else
                        rtest=0.95*rtest;
                end
        end 
figure, stem(Px), hold on, stem(Py,'r')

K=length(move_L);
Qxy=double(zeros(length(Px),length(Py)));
Qyx=double(zeros(length(Py),length(Px)));
start=0;

for i=1:K
%     dis=abs(   sum(Px( start+1:start+Px_sub_L(i) )) -sum( Py (start+1:start+Px_sub_L(i) ))  ) ;
%     if ( dis <10^-10 ) 
[Qxy_sub,Qyx_sub] = nonCrossEdge(Px(start+1:start+Px_sub_L(i)),Py(start+1:start+Px_sub_L(i)));
Qxy(start+1:start+Px_sub_L(i),start+1:start+Px_sub_L(i))=Qxy_sub;
Qyx(start+1:start+Px_sub_L(i),start+1:start+Px_sub_L(i))=Qyx_sub;
start=start+Px_sub_L(i);
%     else
%         error('���������');
%     end
end
% Qyx=pre_processing(Qyx);
Qxy=pre_processing(Qxy);
% [mod_diffs,messLen,extraLen] = recursiveConstruct(Qxy,Qyx,cover,x,y,K);%
% % dHist=round((Py-Px)*N);
% % histLen=round(entropy(dHist)*length(dHist));
% % Llsb=extraLen+histLen;
% 
% messLen = messLen-extraLen;%-Llsb;%%%pure message

mod_diffs =simulate (Qxy,cover,x,y);
messLen=round(0.98*(entropy(mod_diffs)-entropy(cover))*length(cover(:)));
% entropy(mod_diffs)-entropy(cover)
%  appraise_PSNR(cover,mod_diffs)
% sum(abs(cover-mod_diffs))
end

