function [markimage,messL,totalD]=embed(img,messL,K,tag)
img=double(img);
waterMark=img;
[cost,preV,diffs,xpos,ypos]=prediction(img,tag);%%%% ����Ե���������ص�
diffs00=diffs;
cost0=sort(cost);
max_cost=cost0((round(0.4*length(cost))));
costT=min(max_cost,cost0(6*messL));
index=find(cost<costT);

diffs1=diffs(index);
cost1=cost(index);

rate=0.01;
T=46;%%%%%%%%%% 31 is proper
histC=hist(diffs1,-T:T);histC(1)=0;histC(end)=0;
TopC=max(histC);poshist=find(histC>(rate*TopC));
TC=max(abs(poshist(1)-T-1),20); 
L=-TC;
U=TC;

pos_sel =  find( (diffs1>=L)&(diffs1<=U) );
diffs0=diffs1(pos_sel);
cost0=cost1(pos_sel);
%%% figure, hist(diffs,min(diffs):max(diffs))
[move_L,Px_sub_L,sub_index,cover_stitch,D_stitch]=K_means(diffs0,cost0',K,TC);%%%��Ӧ��Ϊcost������
[mod_diffs,messL,flag] =  modifyDiffs(cover_stitch,D_stitch,move_L,Px_sub_L,messL,K,TC); 
if flag==0
    imwrite(uint8(img),'error.png')
%     error('error')
end
%%%%%%%%% ����
%  appraise_PSNR(mod_diffs,cover_stitch)
%    mod_diffs=cover_stitch;
%%%%%%%% ����

index_end=length(mod_diffs);
 for i=K:-1:1
    diffs0(sub_index{i})=mod_diffs(index_end-length(sub_index{i})+1:index_end)-move_L(i);
    index_end=index_end-length(sub_index{i});
 end
 diffs(index(pos_sel))=diffs0;

Ind = sub2ind(size(waterMark),xpos(pos_sel),ypos(pos_sel));
waterMark(Ind) = preV(pos_sel)+diffs(pos_sel);
totalD=sum(cost.*(abs(diffs-diffs00)));
%%%%**** ����
% as=waterMark - img;
% sum(abs(as(:)))
%%%****����


markimage=uint8(waterMark);

end

