function [move_L,Px_sub_L,sub_index,cover_stitch,D_stitch]=K_means(cover,cost,K,T)
%%%% �ú���Ŀ�� �����ݷ�Ϊ K�� ����ÿһ�����������������  ��С�������
% cover=[1,2,3,7,8,9,4,5,6,0]; cost=[1, 2.1, 3, 1.1, 2, 2, 1, 1.4, 3, 1]; K=3
% cover=[1,1,2,1,1,2,1,1,2]; cost=[1, 2, 3, 1, 2, 3,1, 2, 3]; K=3
inf=10^10;
% cost=cost.^2;
move_L=zeros(K,1);
Px_sub_L=zeros(K,1);
% cut_point=(min(cover)-1)*ones(K,1);
cover_stitch=[];
sub_index=cell(K,1);
D_stitch=[];
U=T;
L=-T;
if K>1
K=min(K,length(unique(cost)));
[cost_K,center]=kmeans(cost',K,'distance','sqEuclidean','Start','uniform','rep',2);%%%%%%%% cost_K��Ƕ�Ӧ��ԭʼΪ��һ��
else
cost_K=ones(length(cost),1);
center(1)=1;
end
%%%%%����ʵ��
% L=length(cover);
% cost_K=[ones(floor(L/2),1); 2*ones(floor(L/4),1); 3*ones(L-floor(L/4)-floor(L/2),1)];
% center=[1,2,3];
%%%%%%%
% minCover=zeros(K,1);
% histLen=0;
%center
[center,center_index]=sort(center);
    for i=1:K    
        index=find(cost_K==center_index(i));
%         min(cost(index))
%         max(cost(index))
        sub_index{i}=index;
        temp=cover(index);
%         U=max(temp);
%         L=min(temp);
%         histX=hist(temp,L:U);
%         histLen = compressFun(histX)+histLen;
        Px_sub_L(i)=U-L+1;
                        x = L:U;
                        y = x;
                        % squre error distortion matirx
                        mB = length(x);
                        nB = length(y);
                        Dxy=zeros(mB,nB);
                        for ii=1:mB
                            for jj=1:nB
                                Dxy(ii,jj) =abs(x(ii)-y(jj));
                            end
                        end
                       % Dxy=i*Dxy;
                      Dxy=center(i)*Dxy;
                      D_stitch=[D_stitch inf*ones(size(D_stitch,1),size(Dxy,2));inf*ones(size(Dxy,2),size(D_stitch,1)) Dxy];
                               
        if i>1
            move_L(i)=(i-1)*(2*T+1); 
%             cut_point(i)=max(cover_stitch);
        end
        cover_stitch=[cover_stitch; temp+move_L(i)];    
    end

end


