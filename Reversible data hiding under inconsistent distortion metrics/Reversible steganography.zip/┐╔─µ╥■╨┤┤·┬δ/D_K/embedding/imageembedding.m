function [stego,rea_messLen,totalD]=imageembedding(imgname,messLen,K)
img = double(imread(imgname));
[stego,messLen,totalD]=embed(img,messLen,K,1);
rea_messLen=messLen;
end