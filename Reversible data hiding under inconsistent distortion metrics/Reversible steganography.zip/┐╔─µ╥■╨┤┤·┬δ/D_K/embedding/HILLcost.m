function rho = HILLcost(cover)
% -------------------------------------------------------------------------
% Copyright (c) 2012 DDE Lab, Binghamton University, NY.
% All Rights Reserved.
% -------------------------------------------------------------------------
% Permission to use, copy, modify, and distribute this software for
% educational, research and non-profit purposes, without fee, and without a
% written agreement is hereby granted, provided that this copyright notice
% appears in all copies. The program is supplied "as is," without any
% accompanying services from DDE Lab. DDE Lab does not warrant the
% operation of the program will be uninterrupted or error-free. The
% end-user understands that the program was developed for research purposes
% and is advised not to rely exclusively on the program for any reason. In
% no event shall Binghamton University or DDE Lab be liable to any party
% for direct, indirect, special, incidental, or consequential damages,
% including lost profits, arising out of the use of this software. DDE Lab
% disclaims any warranties, and has no obligations to provide maintenance,
% support, updates, enhancements or modifications.
% -------------------------------------------------------------------------
% Contact: vojtech_holub@yahoo.com | fridrich@binghamton.edu | October 2012
%          http://dde.binghamton.edu/download/steganography
% -------------------------------------------------------------------------
% This function simulates embedding using WOW steganographic 
% algorithm. For more deatils about the individual submodels, please see 
% the publication [1]. 
% -------------------------------------------------------------------------
% Input:  coverPath ... path to the image
%         payload ..... payload in bits per pixel
% Output: stego ....... resulting image with embedded payload
% -------------------------------------------------------------------------
% ��� HLL
% -------------------------------------------------------------------------

%% Get 2D high-pass filters - 3*3 KerBonhme filter
H1 = [-1 2 -1;
      2 -4 2;
      -1 2 -1];
%% Get 2D low-pass filters - average filter
L1 = fspecial('average',[3 3]);
L2 = fspecial('average',[15 15]);

%% Get embedding costs
% inicialization
cover = double(cover);
p = -1;
wetCost = 10^10;
sizeCover = size(cover);

% add padding
padSize = max(size(H1));
coverPadded = padarray(cover, [padSize padSize], 'symmetric');


% compute residual
R = conv2(coverPadded, H1, 'same');
% compute suitability
xi = conv2(abs(R), L1, 'same');
% compute embedding costs \rho
rho = conv2(( (xi.^p) ) .^ (-1/p), L2 , 'same');
% correct the suitability shift if filter size is even
if mod(size(H1, 1), 2) == 0, rho = circshift(rho, [1, 0]); end;
if mod(size(H1, 2), 2) == 0, rho = circshift(rho, [0, 1]); end;
% remove padding
rho = rho(((size(rho, 1)-sizeCover(1))/2)+1:end-((size(rho, 1)-sizeCover(1))/2), ((size(rho, 2)-sizeCover(2))/2)+1:end-((size(rho, 2)-sizeCover(2))/2));


% adjust embedding costs
rho(rho > wetCost) = wetCost; % threshold on the costs
rho(isnan(rho)) = wetCost; % if all xi{} are zero threshold the cost
