% clear
% close all
% clc

cover_dir ='D:\houdd\reversible-steganography\bossdata\images_cover';
len=1000;
imgs = dir(cover_dir);
% ave_D=zeros(4,5);
j=2;

for messL=[10000]
    j=j+1;
    for k=1:5
        Total_D=zeros(len,1);
        parpool('local',12);
        parfor_progress(len);
        params.w=9;
         parfor i=1003:1000+len+2
            name = imgs(i).name;
            cover_img = [cover_dir,'\',name];
            [~,~,Total_D(i-1002)]=imageembedding(cover_img,messL,k)
            parfor_progress;
        end
          poolobj = gcp('nocreate');
          delete(poolobj);
          parfor_progress(0);
          ave_D(j,k)=mean(Total_D)
    end
end
save ave_D ave_D;
 
 
 
 


