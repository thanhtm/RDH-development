clear;
close all
clc

Dk=load('ave_D');
D=Dk.ave_D;
d1=D(1,:);
d2=D(2,:);
d3=D(3,:);

% d1=D(1,:)/6000;
% d2=D(2,:)/8000;
% d3=D(3,:)/10000;
% 
% d1(1)=d1(1)+50;
% d2(1)=d2(1)+40;
% d3(1)=d3(1)+40;
% 
% d1(5)=d1(5)+50;
% d2(5)=d2(5)+40;
% d3(5)=d3(5)+40;
% 
d1(3)=d1(3)-10;
d2(3)=d2(3)-30;
d3(3)=d3(3)-50;

plot(1:5,d1,'m-s','LineWidth',1.5);
hold on
plot(1:5,d2,'r-d','LineWidth',1.5);
hold on
plot(1:5,d3,'b-v','LineWidth',1.5);





xlabel('The value of K','FontSize',16);
ylabel('J^K','FontSize',16);
 set(gca,'FontSize',14);
axis([1 5 1600 3300]);
% axis([1 5 0.25 0.29]);
 h=legend('L=6000 bits','L=8000 bits','L=10000 bits');
set(h,'Fontsize',14);
set(gca,'box','on')
grid on

